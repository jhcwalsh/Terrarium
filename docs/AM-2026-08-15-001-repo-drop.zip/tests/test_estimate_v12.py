"""Unit tests for scripts/estimate_sleeve_mappings_v1_2.py (AM-2026-08-15-001).

Pure-function tests only -- no catalog, no network, no RNG. The catalog-touching
path is exercised by the real run (Task: run + sanity-read, per the plan).
"""

import importlib.util
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

_SPEC = importlib.util.spec_from_file_location(
    "est_v12", Path(__file__).resolve().parents[1] / "scripts" /
    "estimate_sleeve_mappings_v1_2.py"
)
_mod = importlib.util.module_from_spec(_SPEC)
sys.modules["est_v12"] = _mod
_SPEC.loader.exec_module(_mod)


def _idx(n):
    return pd.date_range("1990-03-31", periods=n, freq="QE")


def test_loss_series_shape_and_floor():
    """Below s_bar the loss is exactly zero; above, linear in the excess,
    keyed to the spread as it stood LOSS_LAG_Q quarters earlier."""
    spread = pd.Series([1.0] * 8 + [3.0] * 8, index=_idx(16))
    out = _mod.loss_series(spread, theta=0.01, s_bar=1.5)
    # first non-NaN rows: lagged spread 1.0 < s_bar -> zero
    assert float(out.iloc[0]) == 0.0
    # after the lag catches the 3.0 regime: 0.01 * (3.0 - 1.5)
    assert float(out.iloc[-1]) == pytest.approx(0.015)
    # the transition lands exactly LOSS_LAG_Q quarters after the spread move
    first_nonzero = out[out > 0].index[0]
    assert first_nonzero == spread.index[8 + _mod.LOSS_LAG_Q]


def test_alpha_rebase_preserves_unconditional_mean():
    """alpha_adj = alpha + mean(loss) means mean(alpha_adj - loss) == alpha."""
    rng_free = pd.Series(
        np.linspace(1.0, 4.0, 40), index=_idx(40)
    )  # deterministic 'spread'
    loss = _mod.loss_series(rng_free, theta=0.02, s_bar=2.0)
    alpha = 0.0193
    alpha_adj = alpha + float(loss.mean())
    assert float((alpha_adj - loss).mean()) == pytest.approx(alpha, abs=1e-12)


def test_c1_regressor_demeaned_at_anchor_has_zero_mean():
    """The adopted C1 convention: loading applies to (trail - c_anchor), so
    the term contributes nothing to the unconditional mean by construction."""
    infl_q = pd.Series(
        0.005 + 0.002 * np.sin(np.linspace(0, 6, 60)), index=_idx(60)
    )
    trail = (infl_q.rolling(_mod.CPI_TRAIL_K).mean() * 4.0).dropna()
    anchor = float(trail.mean())
    assert float((trail - anchor).mean()) == pytest.approx(0.0, abs=1e-12)


def test_fit_sum_beta_reproduction_matches_v11_machinery():
    """The duplicated fit recovers a known summed beta on synthetic data --
    the same construction the v1.1 plan used as its defect-reproduction test."""
    rng = np.random.default_rng(7)
    n = 400
    f = rng.standard_normal(n) * 0.05
    true = 1.0 * f
    obs = 0.5 * true + 0.3 * np.roll(true, 1) + 0.2 * np.roll(true, 2)
    obs[:2] = true[:2]
    idx = pd.date_range("1950-01-01", periods=n, freq="QS")
    x = pd.DataFrame({r: np.zeros(n) for r in _mod.REGRESSORS}, index=idx)
    x["equity_mkt"] = f
    y = pd.Series(obs, index=idx)
    spec = {r: (0.0, 0.0, 0.0) for r in _mod.REGRESSORS}
    spec["equity_mkt"] = (0.0, float("inf"), 1.0)
    summed, _a, _r, _yv = _mod.fit_sum_beta(y, x, spec, n_lags=2)
    assert abs(summed[0] - 1.0) < 0.15


def test_b_infl_only_on_declared_sleeves():
    assert set(_mod.B_INFL) == {"pm_infra", "pm_re_value_add"}
    assert set(_mod.LOSS_SLEEVES) == {
        "pm_direct_lending", "pm_mezzanine", "pm_distressed"
    }
    # PE sleeves carry neither term -- the SS1 scope table, machine-checked
    for s in ("pm_buyout", "pm_growth", "pm_vc", "pm_secondaries"):
        assert s not in _mod.B_INFL and s not in _mod.LOSS_SLEEVES
