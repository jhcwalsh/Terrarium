# AM-2026-08-15-001 — Commit Plan

Order is the evidence: the note lands before the estimator, and the estimator
never runs before the note is in history. Branch per the remap pattern:
`c1c2-01-authored-terms`, merge `--no-ff` only after the gate stamps.

---

## Commit 1 — the declaration

**Files:**
```
docs/superpowers/specs/2026-08-15-inflation-passthrough-credit-loss-design.md
<decision register file>          # Ruling A entry + two ⚑ entries (text below)
<amendment register file>         # AM-2026-08-15-001 block (text below)
```

**Register entry — Ruling A (dated, owner-attributed, precedent-setting):**
> **SM-RULING-A (2026-08-15, owner).** External-series comparison of a
> pre-committed authored coefficient against published prints is validation
> evidence, not holdout access, under four conditions and no wider:
> (i) external series only, never a catalog factor read; (ii) the compared
> value committed and hashed before the check; (iii) one execution, result
> recorded verbatim; (iv) never a calibration input — a failed check is
> disclosed and reopened only via a further dated amendment whose stated
> trigger is the failure. Context: AM-2026-08-15-001 §3.3 (NPI 2021–24
> inflation pass-through check). Rationale: the inflation channel is too
> material to ship unchecked.

**Register entries — ⚑ (unratified until the owner release event):**
> ⚑ C1 adoption — inflation pass-through term (pm_infra 0.6, pm_re_value_add
> 0.3, both `chosen`); measured-external upgrade = NPI NOI-growth fit via
> NCREIF query-tool export (membership, data register P1).
> ⚑ C2 adoption — credit loss term (θ per CDLI match rule, `chosen`); upgrade
> path = Albourne derived-measures interface (loss dispersion).

**Amendment block (conform to the register's format):**
```yaml
AM-2026-08-15-001:
  date: 2026-08-15
  post_hoc: true
  trigger: >
    design review finding: missing slow inflation channel on real-asset
    sleeves; linear credit payoff understates stressed-state losses
  design_note: docs/superpowers/specs/2026-08-15-inflation-passthrough-credit-loss-design.md
  declares:
    - C1 form (K=8 trailing CPI, c_anchor demeaning), values chosen
    - C2 form (theta * max(ig_spread_{t-4} - s_bar, 0), alpha re-based),
      theta from declared CDLI match rule
    - r2_train_val restored to PM rows via v1.1 reproduction check
    - Ruling A (see register)
  supersedes: nothing; sleeve-mappings-v1.1.yaml remains sealed and unedited
```

**Message:**
```
docs: AM-2026-08-15-001 pre-declaration - inflation pass-through + credit
loss term (chosen, authored); Ruling A recorded

post_hoc: true (trigger: design review). Forms, lags, anchors, adoption and
theta-match rules fixed here before any estimation runs. Measured plane
untouched. Ruling A entered in the register as scoped precedent.

Co-Authored-By: Claude <noreply@anthropic.com>
```

## Commit 2 — machinery + its quoted evidence

**Files:**
```
scripts/fit_inflation_passthrough.py
scripts/fit_credit_loss_theta.py
artifacts/c1/passthrough-rent-crosscheck.json
.gitignore                        # allowlist lines below
```

**.gitignore addition** (per-file allowlist — the standing trap: each future
artifact in c1/c2 needs its OWN lines or it is silently ignored):
```
# AM-2026-08-15-001 evidence: the design note quotes these numbers (rent
# cross-check 0.64 LR / 72% at K=8; theta + GFC verdict), so they are
# committed on the campaign-3 rule -- nothing else in the repo would hold them.
!/artifacts/c1/
/artifacts/c1/*
!/artifacts/c1/passthrough-rent-crosscheck.json
!/artifacts/c2/
/artifacts/c2/*
!/artifacts/c2/theta-provenance.json
```

**Inputs NOT committed** (hashes travel in provenance): `rent_q.csv`
(rebuilds from one FRED fetch of CUUR0000SEHA — regeneration line in the
script docstring), the CDLI CSV (registration-tier).

**Message:**
```
feat: C1/C2 calibration machinery + rent cross-check provenance

fit_inflation_passthrough.py enforces the sealed 2020-12-31 boundary in code
(post-boundary rows quarantined to the Ruling-A block). Rent cross-check:
LR pass-through 0.64, cum share 47/72/88% at K=4/8/12, contemporaneous t=0.5
-- lag-shape evidence only, never a b_infl source. Deterministic, verified.

Co-Authored-By: Claude <noreply@anthropic.com>
```

## Commit 3 — the v1.2 estimator (TDD)

**Files:**
```
scripts/estimate_sleeve_mappings_v1_2.py
tests/test_estimate_v12.py
```
Tests pass with no data layer present (ah imports deferred to call time);
the catalog path is exercised by the real run. Lint/type per house rules
(`ruff check --fix`, `ruff format`, pyright log read as its own step).

**Message:**
```
feat: v1.2 estimator - C1 + C2 + r2_train_val via v1.1 reproduction (TDD)

Measured plane verbatim: the script REFITS the v1.1 regression solely to
obtain residuals for R2 and refuses (tol 1e-3) if the reproduced betas do
not match the sealed artifact -- the R2 restoration doubles as a v1.1
reproducibility check. Refuses a theta provenance whose GFC verdict != PASS.

Co-Authored-By: Claude <noreply@anthropic.com>
```

## Then: run, sanity-read, adopt (NOT in this drop)

1. Export CDLI losses → `fit_credit_loss_theta.py` → verdict must be PASS.
2. `estimate_sleeve_mappings_v1_2.py --theta artifacts/c2/theta-provenance.json`
   Run twice; `git diff --stat` shows nothing (determinism).
3. Sanity expectations (record surprises, do not tune): PM r2_train_val
   ordering should sort with the reconstructed table (distressed ≈ 0.7 …
   RE value-add ≈ 0.07); DL/mezz/distressed alpha_quarterly rises by exactly
   mean(loss_q); no PE row gains any new field beyond r2.
4. Commit artifact + report with the numbers in the body; three-lock digest
   check after any sealed-adjacent edit (two-seals-check-both-scopes).
5. **Adoption is a named owner release event** (`ah/port/mapping.py`
   ARTIFACT_PATH bump + world_id block move for touched presets), a separate
   commit the owner triggers — the Campaign R1 rule.

## Deferred, tracked, not in this drop

- NPI export (NOI growth + income return, quarterly to inception, national)
  → `fit_inflation_passthrough.py` → `chosen` → `measured-external` relabel
  by amendment. Add the export to the NCREIF membership scope conversation.
- Ruling-A one-shot 2021–24 check: spec (series, window, tolerance) is
  hashed at coefficient adoption per §6 item 3 of the note.
- Linkage document + R² reconstruction from this conversation: revise once
  against MAPPINGS-v1.2.md, then commit — not before.
- RE d_level gap (cap-rate channel): now more visible with C1 in place;
  candidate for the next structural-term amendment, same pattern.
