# TASK 2 — Addendum: sources supplied, rulings issued

## Unblocking

The two Markdown sources now accompany this addendum (drop the bundle at repo root or `docs/`):

- `D-05-methodology-note.md` (v0.2, with its five `d05-fig*.svg` figures)
- `P1-specified-world-models-preprint.md` (v0.2, third-person, with `fig1`–`fig7` SVGs)

These are the canonical sources; the PDF in `Instructions/` is a rendering of the P1 markdown, now superseded for editing purposes. Commit the markdown sources first, then proceed with Parts B–D of the original brief under the rulings below, which resolve every question you raised. Your two-battery finding was correct and materially improves the task — thank you for stopping instead of improvising.

---

## Ruling 1 — The two batteries are reported separately, never aggregated

Your reading is adopted: there are two batteries with different standings, and conflating them misstates both.

**Step-2 battery (the generator battery): report as pre-registered.** Thresholds hashed together with the judging code, sealed 2026-07-26, re-sealed 2026-08-02, results recorded after. The G2 four-clause verdict table, the campaign-2 promotion (mean_d −0.3157, sd 0.0265, n=3), the holdout, and the severe test are all reportable as pre-registered pass/fail, subject to Rulings 2 and 3.

**Step-0 battery (the stylised panel): report as descriptive, gates open.** All seven `status: todo`. See Ruling 4 for the path forward. In both documents, the Step-0 section states plainly: thresholds drafted 2026-07-24, never ratified; six of seven metrics unmeasured; the panel's pre-registered evaluation is pending.

Each document gets a short standing table naming the two batteries, their seal status, and their evidentiary weight — as a methods fact, top of the results material, not a footnote.

## Ruling 2 — Campaign-2 same-day ordering: hash linkage is accepted as the proof, with disclosure

Accept `prereg_verified` **if and only if** it is a mechanical content-address check — i.e. the verdict record embeds the hash of the thresholds artifact it was judged against, and that hash matches the sealed 2026-08-02 file. Verify this yourself and quote the hashes in the provenance block.

Rationale to state in the documents (one footnote, both documents): content-addressed linkage proves the verdict was computed against exactly the sealed thresholds — which is the substantive pre-registration claim; the timestamp is a proxy for it, and here the stronger evidence replaces the weaker. The same-date fact is disclosed in the same footnote, not omitted. If `prereg_verified` turns out to be a manual flag rather than a hash check, the ruling reverses: campaign-2 reports as post-hoc, per the original rule 3.

## Ruling 3 — RFR-66 travels with the result, everywhere

RFR-66 (the sealed record that the G2 head-to-head is biased toward promotion by the benchmark's data window) is quoted wherever the kill-criterion outcome is reported — in D-05 §6's results table as a margin-column note, and in P1's empirical section as its own sentence. It is never summarised away.

Frame it as what it is: a pre-registered, self-recorded caveat — the pre-registration discipline catching its own thumb on the scale and saying so in advance. That is the strongest kind of evidence the honesty claims in both documents can cite, and it should be presented with that valence, not buried as an embarrassment.

## Ruling 4 — Step-0 panel: ratify the blind six now; the seventh is disclosed

The elegant fact in your report: only **one** of the seven Step-0 metrics has ever been observed (acf_r_lag1 = 0.364, ER-5). The other six are still blind. Therefore:

1. **Do not fill Step-0 slots from new runs.** Rule 5 stands: no battery execution while gates are todo.
2. **Recommend in your output** (do not execute — it is a human ratification act) that the six unobserved metrics be ratified immediately, while blindness holds. Pre-registration for six of seven is preserved by acting now and forfeited by waiting.
3. **The seventh (acf_r_lag1)**: report the observed 0.364 against the drafted [−0.2, +0.2] band as *descriptive*, stating the full ordering — band drafted 2026-07-24 unratified, statistic observed 2026-08-04, therefore observed-before-ratification; pre-registered evaluation of this metric applies from the next generator version. It is a miss by 0.164 and is reported as a miss, with the same prominence a pass would have had.
4. The D-05 Step-0 slots that cannot be filled carry: *"awaiting post-ratification battery run; thresholds ratification recommended [date] — see evidence inventory."*

## Ruling 5 — Figures (Part D, revised)

Draw only what recorded data supports today: the benchmark comparison (campaign-2), and — as a second exhibit — a **pre-registration timeline figure**: the two batteries on one time axis showing seal dates, re-seal, the 2026-08-04 run, and ratification status per gate. That figure is the standing table of Ruling 1 made visual and will be reused in the evidence pack. The stylised-fact panel figure and the tail figure are deferred with a note, matching their open slots.

## Unchanged

All honesty rules of the original brief stand. The closing deliverable remains: slots filled, slots open with reasons, the per-gate determination with git evidence (now organised by the two-battery split), and the list of results the existing claims sit uncomfortably with — to which add explicitly: does the acf_r_lag1 miss, read alongside RFR-66, place tension on any sentence currently in D-05 §6 or P1's abstract? Quote the sentences if so.
